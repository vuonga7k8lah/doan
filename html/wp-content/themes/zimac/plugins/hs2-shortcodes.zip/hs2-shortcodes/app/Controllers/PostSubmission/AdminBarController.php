<?php

namespace HSSC\Controllers;


/**
 * Class AdminBarController
 * @package HSBlogCore\Controllers
 */
class AdminBarController
{
	public function __construct()
	{
	}
}
